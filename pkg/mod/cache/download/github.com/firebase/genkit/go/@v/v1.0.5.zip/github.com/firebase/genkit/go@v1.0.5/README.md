# Genkit

This package is the Go version of Genkit, a framework for building
AI-powered apps. See: https://genkit.dev/go/docs/get-started-go
